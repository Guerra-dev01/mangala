-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 11, 2022 at 07:06 AM
-- Server version: 10.4.24-MariaDB-cll-lve
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oasisitm_mangala`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabDenuncia`
--

CREATE TABLE `tabDenuncia` (
  `codDen` int(11) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `email` varchar(40) NOT NULL,
  `idade` int(11) NOT NULL,
  `contacto` int(11) NOT NULL,
  `localizacao` varchar(60) NOT NULL,
  `sexo` varchar(20) NOT NULL,
  `cod_Prov` int(11) NOT NULL,
  `cod_Cid` int(11) NOT NULL,
  `assunto` varchar(255) NOT NULL,
  `descricao` int(11) NOT NULL,
  `imagem` blob NOT NULL,
  `audio` blob NOT NULL,
  `video` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbCidade`
--

CREATE TABLE `tbCidade` (
  `codCid` int(11) NOT NULL,
  `nome` varchar(40) NOT NULL,
  `cod_Prov` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbDadosEmpresa`
--

CREATE TABLE `tbDadosEmpresa` (
  `codEmp` int(11) NOT NULL,
  `nome` varchar(60) NOT NULL,
  `nuit` varchar(10) NOT NULL,
  `contacto1` int(11) NOT NULL,
  `contacto2` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `cidade` varchar(40) NOT NULL,
  `bairro` varchar(60) NOT NULL,
  `avenida` varchar(60) NOT NULL,
  `nrcasa` int(11) NOT NULL,
  `logotipo` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbProvincia`
--

CREATE TABLE `tbProvincia` (
  `codProv` int(11) NOT NULL,
  `nome` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbUtilizador`
--

CREATE TABLE `tbUtilizador` (
  `codUtil` int(11) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `username` int(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `contacto` int(11) NOT NULL,
  `papel` varchar(80) NOT NULL,
  `criado_aos` date NOT NULL,
  `esta_activo` int(2) NOT NULL,
  `foto` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbCidade`
--
ALTER TABLE `tbCidade`
  ADD PRIMARY KEY (`codCid`),
  ADD KEY `cod_Prov` (`cod_Prov`);

--
-- Indexes for table `tbDadosEmpresa`
--
ALTER TABLE `tbDadosEmpresa`
  ADD PRIMARY KEY (`codEmp`);

--
-- Indexes for table `tbProvincia`
--
ALTER TABLE `tbProvincia`
  ADD PRIMARY KEY (`codProv`);

--
-- Indexes for table `tbUtilizador`
--
ALTER TABLE `tbUtilizador`
  ADD PRIMARY KEY (`codUtil`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbCidade`
--
ALTER TABLE `tbCidade`
  MODIFY `codCid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbDadosEmpresa`
--
ALTER TABLE `tbDadosEmpresa`
  MODIFY `codEmp` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbProvincia`
--
ALTER TABLE `tbProvincia`
  MODIFY `codProv` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbUtilizador`
--
ALTER TABLE `tbUtilizador`
  MODIFY `codUtil` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbCidade`
--
ALTER TABLE `tbCidade`
  ADD CONSTRAINT `tbCidade_ibfk_1` FOREIGN KEY (`cod_Prov`) REFERENCES `tbProvincia` (`codProv`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
